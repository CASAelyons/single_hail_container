#include <curl/curl.h>
#include <netcdfcpp.h>
#include <stdio.h>
#include <string.h>
#include <iostream>
#include <vector>
#include <fstream>
#include <algorithm>
#include <argp.h>
#include <float.h> 
#include <libconfig.h>
#include "./json.hpp"

using json = nlohmann::json;
using std::cout;
using std::endl;
using std::string;

#define MAX_NAME 1024

typedef std::pair<double,double> coordPair;

typedef struct fragment
{
		double start =-1;
		double end =-1;
		std::vector<std::pair<double,double>> ring;
}fragment;

char commandline[]= "d3_cpp <-c configfile> <-t threshold> [input_filename]";

static struct argp_option options[] = {
  {"configfile", 'c', "configuration_file",    0,   "Specify name of configuration file"},
  {"threshold",  't', "threshold",             0,   "Specify integer threshold"},
  { 0 }
};

struct arguments{
  char config_filename[MAX_NAME];
  char *i_filename;
  float threshold;
};

static error_t parse_opt(int key, char *arg, struct argp_state *state){
  struct arguments *arguments = static_cast<struct arguments*>(state->input);
  switch(key){
  case 'c':
    if (arg[0] != '-')
      strncpy(arguments->config_filename,arg,MAX_NAME);
    else {
      printf("arguments should not begin with a - sign.  Exiting...\n");
      exit(0);
    }
    break;
  case 't':
    arguments->threshold = atof(arg);
    break;
  case ARGP_KEY_ARG:
    arguments->i_filename = arg;
    break;
  case ARGP_KEY_END:
    if(state->arg_num<1)
      argp_usage(state);
    break;
  default:
    return ARGP_ERR_UNKNOWN;
  }
  return 0;
}

static struct argp argp = {options,parse_opt,"$Id: d3_cpp.cpp,v 1.0 2019-08-20 14:45:10 agrote, elyons Exp $"};



//Important global Variables


double cases[16][2][2][2] = {//Cases used for Marching Sqaures
  {{{-1, -1}, {-1, -1}},    {{-1, -1}, {-1, -1}}},
  {{{1.0, 1.5}, {0.5, 1.0}},{{-1, -1}, {-1, -1}}},
  {{{1.5, 1.0}, {1.0, 1.5}},{{-1, -1}, {-1, -1}}},
  {{{1.5, 1.0}, {0.5, 1.0}},{{-1, -1}, {-1, -1}}},
  {{{1.0, 0.5}, {1.5, 1.0}},{{-1, -1}, {-1, -1}}},
  {{{1.0, 1.5}, {0.5, 1.0}}, {{1.0, 0.5}, {1.5, 1.0}}},
  {{{1.0, 0.5}, {1.0, 1.5}},{{-1, -1}, {-1, -1}}},
  {{{1.0, 0.5}, {0.5, 1.0}},{{-1, -1}, {-1, -1}}},
  {{{0.5, 1.0}, {1.0, 0.5}},{{-1, -1}, {-1, -1}}},
  {{{1.0, 1.5}, {1.0, 0.5}},{{-1, -1}, {-1, -1}}},
  {{{0.5, 1.0}, {1.0, 0.5}}, {{1.5, 1.0}, {1.0, 1.5}}},
  {{{1.5, 1.0}, {1.0, 0.5}},{{-1, -1}, {-1, -1}}},
  {{{0.5, 1.0}, {1.5, 1.0}},{{-1, -1}, {-1, -1}}},
  {{{1.0, 1.5}, {1.5, 1.0}},{{-1, -1}, {-1, -1}}},
  {{{0.5, 1.0}, {1.0, 1.5}},{{-1, -1}, {-1, -1}}},
  { {{-1, -1}, {-1, -1}},{{-1, -1}, {-1, -1}} }
};

//Function Declarations

double max_XValue(std::vector<std::pair<double,double>> polygon);

int pointInside(coordPair point, std::vector<std::pair<double,double>> polygon );

std::vector<std::pair<double,double>> toLongAndLat(std::vector<std::pair<double,double>> polygon, float latlist[], int latsz, float lonlist[], int lonsz);

//Function Declarations----End

std::pair<double,double> MAXPAIR = std::make_pair(FLT_MAX,FLT_MAX);

int ringCount = 0;

int segCnt = 0;

int x;//current x index

int y;//current y index

int dx;

int dy;

std::vector<std::vector<std::pair<double,double>>> polygons;

std::vector<std::vector<std::pair<double,double>>> holes;

std::vector<std::vector<std::pair<double,double>>> polygonTemp;

std::vector<std::vector<std::vector<std::pair<double,double>>>> polygonCollection;

int pointInPoly( std::vector<std::pair<double,double>> polygon, coordPair test);


void noop(){
;}


int checkCaseLength(int index){
	int count  = 2;
	for(int i =0; i<2;i++){
		if(cases[index][i][0][0] == -1) count--;
	}
	return (count-1);
}


int checkMap(double index, std::map<double,fragment> map ){
	std::map<double,fragment>::iterator it;
	it = map.find(index);
	if(it != map.end()) return 1;
	else return 0;
			}
void eraseFragment(double index, std::map<double,fragment> &map ){
	std::map<double,fragment>::iterator it;
	it = map.find(index);
	map.erase(it);
	if(it ==map.end()){
	cout<<"Erase Error\n";
}
			}

int compareFragments(fragment frag1,fragment frag2){
	int cmp = 0;
	if(frag1.start != frag2.start) return 0;   
	else if(frag1.ring != frag2.ring) return 0;
	else if(frag1.end != frag2.end) return 0;
	else return 1;
}




int indexPoint(std::pair<double,double> point){
 return (((point.first)*2)+(point.second)*(dx+1)*4);
}

int area(std::vector<std::pair<double,double>> ring){
	int i = 0;
	int n = ring.size();
	ringCount++;
	double area = ring.at(n-1).second*ring.at(0).first - ring.at(n-1).first*ring.at(0).second;
	while((i++)<(n-1)){
		area+= ring.at(i-1).second*ring.at(i).first - ring.at(i-1).first*ring.at(i).second;
	}
	//cout<<"Made it\n";
	return area;
}



int orient(std::pair<double,double> pointA, std::pair<double,double> pointB, std::pair<double,double> pointC) { 

    double val = (pointB.second - pointA.second) * (pointC.first - pointB.first) - (pointB.first - pointA.first) * (pointC.second - pointB.second); 
  
    if (val == 0) return 0;  // colinear 
  
    return (val > 0)? 1: 2; // clockwise or counterclock wise 
} 

int onSegment(coordPair pointA, coordPair pointB, coordPair pointC){
    if (pointB.first <= std::max(pointA.first, pointC.first) && pointB.first >= std::min(pointA.first, pointC.first) && 
        pointB.second <= std::max(pointA.second, pointC.second) && pointB.second >= std::min(pointA.second, pointC.second)) return 1; 
  
    return 0; 
}

int segmentsIntersect(coordPair pointA1,coordPair pointA2,coordPair pointB1,coordPair pointB2){


	int t0,t1,t2,t3;
	t0 = orient(pointA1,pointA2,pointB1);
	t1 = orient(pointA1,pointA2,pointB2);
	t2 = orient(pointB1,pointB2,pointA1);
	t3 = orient(pointB1,pointB2,pointA2);

	if(t0 != t1 && t2 != t3) return 1;
	if (t0 == 0 && onSegment(pointA1, pointB1, pointA2)) return 1; 
	if (t1 == 0 && onSegment(pointA1, pointB2, pointA2)) return 1; 
	if (t2 == 0 && onSegment(pointB1, pointA1, pointB2)) return 1; 
	if (t3 == 0 && onSegment(pointB1, pointA2, pointB2)) return 1; 


	return 0;
}




coordPair lineLineIntersection(coordPair A, coordPair B, coordPair C, coordPair D) 
{ 
    // Line AB represented as a1x + b1y = c1 
    double a1 = B.second - A.second; 
    double b1 = A.first - B.first; 
    double c1 = a1*(A.first) + b1*(A.second); 
  
    // Line CD represented as a2x + b2y = c2 
    double a2 = D.second - C.second; 
    double b2 = C.first - D.first; 
    double c2 = a2*(C.first)+ b2*(C.second); 
  
    double determinant = a1*b2 - a2*b1; 
  
    if (determinant == 0) 
    { 
        // The lines are parallel. This is simplified 
        // by returning a pair of FLT_MAX 
        return std::make_pair(FLT_MAX,FLT_MAX); 
    } 
    else
    { 
        double x = (b2*c1 - b1*c2)/determinant; 
        double y = (a1*c2 - a2*c1)/determinant; 
        return std::make_pair(x, y); 
    } 
} 

int inside(std::vector<std::pair<double,double>> polygon, std::vector<std::pair<double,double>> hole){
	int intersecting = 0;
	int pointInsideCheck =0;
	for(std::vector<std::pair<double,double>>::iterator itr = polygon.begin(); itr<(polygon.end()-1);itr++ ) {
		
		for(std::vector<std::pair<double,double>>::iterator itr2 = hole.begin(); itr2<(hole.end()-1);itr2++ ) {
			coordPair p1 = *itr;
			coordPair p2 = (*(itr+1));
			coordPair h1 = *itr2;
			coordPair h2 = (*(itr2+1));
			intersecting += segmentsIntersect(p1, p2, h1, h2);



		}
	
			
	//cout<<"p1: ("<<(*(itr)).first<<", "<<(*(itr)).second<<")\n";
	} 

	pointInsideCheck = pointInPoly(polygon,hole[0]);

		//cout<<"Point Inside? "<<pointInsideCheck;
	if(intersecting == 0 && pointInsideCheck ) return 1;
	else
	return 0;
}


double max_XValue(std::vector<std::pair<double,double>> polygon){
	std::vector<std::pair<double,double>>::iterator itr = polygon.begin();
	double currentX = 0;
	double max = (*itr).first;
	for(itr = polygon.begin(); itr<(polygon.end());itr++ ) {
	currentX = (*itr).first;
	if(currentX>max){
	max = currentX;
		}	
	}
	return max;
}

int pointInside(coordPair point, std::vector<std::pair<double,double>> polygon ){
	int intersections =  0;
	coordPair r1 = point;
	coordPair r2 ((max_XValue(polygon))+1,point.second);
	
	std::vector<std::pair<double,double>> checked;
	
	
	coordPair currentStart;
	coordPair previousEnd;
	coordPair temp;
	int countedBool = 0;

	std::vector<std::pair<double,double>>::iterator itr = polygon.begin();
	std::vector<std::pair<double,double>>::iterator itr2;

	for( itr = polygon.begin(); itr<(polygon.end()-1);itr++ ) {
			
			
			//checkedCnt = 0;
			coordPair p1 = *itr;
			coordPair p2 = (*(itr+1));
			//cout<<"p1: ("<<p1.first<<", "<<p1.second<<")\n";
			//cout<<"p2: ("<<p2.first<<", "<<p2.second<<")\n";
			

			temp = lineLineIntersection(r1,r2,p1,p2);
			if(segmentsIntersect(r1,r2,p1,p2)&&temp!=MAXPAIR){
			
				for( itr2 = checked.begin(); itr2!=checked.end();itr2++ ) {
					if(temp==(*itr2)) countedBool++;
				

				}
				if(countedBool == 0) {
					checked.push_back(temp);
					//cout<<"Intersection: ("<<temp.first<<", "<<temp.second<<")\n";
				}


			}

			
			

			}
	
	intersections = checked.size();
	return intersections%2;
}


void pushHoles(float latarray[], int latnos, float lonarray[], int lonnos){

	std::vector<std::vector<std::pair<double,double>>>::iterator itPOLY;

	std::vector<std::vector<std::pair<double,double>>>::iterator itHOLE;
	
	for ( itPOLY = polygons.begin() ; itPOLY != polygons.end(); ++itPOLY){

		std::vector<std::vector<std::pair<double,double>>> polygonTempPush;
		polygonTempPush.push_back(toLongAndLat(*itPOLY, latarray, latnos, lonarray, lonnos));

		for ( itHOLE = holes.begin() ; itHOLE < holes.end(); ++itHOLE){
			
				if(itPOLY-polygons.begin() == 4 ){
noop();
	}
				if(inside((*itPOLY),(*itHOLE))){
					//--itHOLE;
				  polygonTempPush.push_back(toLongAndLat(*itHOLE, latarray, latnos, lonarray, lonnos));
					//holes.erase(itHOLE);
					//cout<<itPOLY-polygons.begin()<<"HOLE PUSHED\n";
				}
			



		}
	polygonCollection.push_back(polygonTempPush);

	}







}





int pointInPoly( std::vector<std::pair<double,double>> polygon, coordPair test){
	int i,j,c = 0;
	int nvert = polygon.size();

  	for (i = 0, j = nvert-1; i < nvert; j = i++) {
   	 if ( ((polygon[i].second  >test.second) != (polygon[j].second>test.second)) &&
	 	(test.first < (polygon[j].first-polygon[i].first) * (test.second-polygon[i].second) / (polygon[j].second-polygon[i].second) + polygon[i].first) )
       		c = !c;
  	}

return c;
}


std::vector<std::pair<double,double>> toLongAndLat(std::vector<std::pair<double,double>> polygon, float latlist[], int latsz, float lonlist[], int lonsz){
  std::vector<std::pair<double,double>>::iterator it;
  for(it = polygon.begin();it!=polygon.end();it++){
    
    (*it).first = (double)lonlist[(int)(*it).first];
    (*it).second = (double)latlist[(350-((int)(*it).second))-1];
    
  }
  
	
	return polygon;
}


int checkValues(double value, float threshold){
	if(value>=threshold) return 1;
	else return 0;
}


void push_ring(std::vector<std::pair<double,double>> ring){
	if(area(ring) >0) {
		polygons.push_back(ring);
	} 
	else{ 
		holes.push_back(ring);
	}
}



void stitch(double line[2][2]){
	coordPair  start(line[0][0] +  (x), line[0][1] + (y));
	coordPair    end(line[1][0] +  (x), line[1][1] + (y));
	//cout<<"stitch!||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||\n";
	//cout<<line[0][0]<<" "<<line[0][1]<<" "<<line[1][0]<<" "<<line[1][1]<<endl<<endl;
	//cout<< "Start: "<<start.first<<", "<<start.second<<" ";
	//cout<< "End: "<<end.first<<", "<<end.second<<" ------ ";
        //cout<< "XY: ("<<x<<", "<<y<<") "<<endl;
	//printf("Start: %f, %f End: %f, %f\n",line[0][0],line[0][1],line[1][0],line[1][1]);

	double startIndex = indexPoint(start);
	double endIndex = indexPoint(end);
	fragment f;
	fragment g;

	//cout<< "Start: "<<startIndex<<" ,End: "<<endIndex<<"\n";
	//system("read -p 'Press Enter to continue...' var");

	



	if(startIndex==911){
	noop();
}

	fragment tempFrag;///Pausing Here
	std::vector<std::pair<double,double>> tempRing;

	static std::map<double,fragment> fragmentByStart;
	static std::map<double,fragment> fragmentByEnd;
	//cout<<checkMap(startIndex,fragmentByEnd)<<endl; //debugging line
	if(checkMap(startIndex,fragmentByEnd)){
		f = fragmentByEnd[startIndex];
		//cout<<"A1\n";
		if(checkMap(endIndex,fragmentByStart)){
			//cout<<"A2\n";
			g = fragmentByStart[endIndex];
			eraseFragment(f.end,fragmentByEnd);
			eraseFragment(g.start,fragmentByStart);

			//cout<<"CMP Debugging: "<<endl;
			//cout<< "f: "<<f.start<<", "<<f.end<<"\n";
			///cout<< "g: "<<g.start<<", "<<g.end<<"\n";
			//cout<<endl;





			
			if(compareFragments(f,g)){
				//cout<<"A3\n";
				//cout<<"Ring Pushed 1\n";
				f.ring.push_back(end);
				push_ring(f.ring);
				}
			else{
			//cout<<"A4\n";
			tempRing.insert(tempRing.begin(),f.ring.begin(),f.ring.end());			
			tempRing.insert(tempRing.end(),g.ring.begin(),g.ring.end());

			tempFrag.start = f.start;
			tempFrag.end = g.end;
			tempFrag.ring = tempRing;
			fragmentByStart[f.start] = fragmentByEnd[g.end] = tempFrag;
			}
		}
		else{
		//cout<<"A5\n";
		eraseFragment(f.end,fragmentByEnd);
		eraseFragment(f.start,fragmentByStart);
		f.ring.push_back(end);
		f.end=endIndex;
		fragmentByEnd[f.end]=f;
		fragmentByStart[f.start] = f;
		}
	}
	else if(checkMap(endIndex, fragmentByStart)){
		//cout<<"B1\n";
		f = fragmentByStart[endIndex];
		if(checkMap(startIndex,fragmentByEnd)){
			//cout<<"B2\n";
			g = fragmentByEnd[startIndex];
			eraseFragment(f.start,fragmentByStart);
			eraseFragment(g.end,fragmentByEnd);

			//cout<<"CMP Debugging2: "<<endl;
			//cout<< "f: "<<f.start<<", "<<f.end<<"\n";
			//cout<< "g: "<<g.start<<", "<<g.end<<"\n";
			//cout<<endl;

			if(compareFragments(f,g)){
				//cout<<"B3\n";
				//cout<<"Ring Pushed 2\n";
				f.ring.push_back(end);
				push_ring(f.ring); 
				
				}
			else{
			//cout<<"B4\n";
			tempRing.insert(tempRing.begin(),g.ring.begin(),g.ring.end());			
			tempRing.insert(tempRing.end(),f.ring.begin(),f.ring.end());

			tempFrag.start = g.start,
			tempFrag.end = f.end,
			tempFrag.ring = tempRing;
			fragmentByStart[g.start] = fragmentByEnd[f.end] = tempFrag;
			}
		}
		else{
		//cout<<"B5\n";
		eraseFragment(f.start,fragmentByStart);
		eraseFragment(f.end, fragmentByEnd);
		f.ring.insert(f.ring.begin(),start);
		f.start = startIndex;
		fragmentByStart[f.start]=f;
		fragmentByEnd[f.end]=f;
		}
	}
	else{
		//cout<<"C\n";
		tempRing.push_back(start);
		tempRing.push_back(end);
		tempFrag.start = startIndex;
		tempFrag.end = endIndex;
		tempFrag.ring = tempRing;
		fragmentByStart[startIndex] = fragmentByEnd[endIndex]= tempFrag;
		
	}
			
	
}

void marchingSquares(float threshold, std::vector<double> values){
	int t0= 0,t1= 0,t2 =0,t3= 0;
	x =-1;
	y =-1;
	int caseNum = 0;
	int checkCaseCount=0;

	//edge case--top
	t1 =(values[0] >= threshold);
	caseNum  = t1<<1;
	//if((caseNum != 0)&&(caseNum != 15)) {segCnt++; cout<<caseNum<<" SEGINC!\n\n";}
	for(int i = 0; i<= checkCaseLength(t1<<1);i++) stitch(cases[t1<<1][i]);
	while (++x < dx -1 ){
		
		t0=t1;
		t1 = (values[x+1]>= threshold);
		caseNum = t0 | t1 << 1;
		//if((caseNum != 0)&&(caseNum != 15)) {segCnt++; cout<<caseNum<<" SEGINC!\n\n";}

		checkCaseCount = checkCaseLength(t0 | t1 << 1);
		//printf("cnt: %d\n",checkCaseCount);
		//printf("Case: %d\n",(t0 | t1 << 1));
		for(int i = 0; i<= checkCaseLength(t0 | t1 << 1);i++) {
				stitch(cases[t0 | t1 << 1][i]);
				
				}
				
	}
		caseNum = t1<<0;
		//if((caseNum != 0)&&(caseNum != 15)) {segCnt++; cout<<caseNum<<" SEGINC!\n\n";}

	for(int i = 0; i<= checkCaseLength(t1 << 0);i++) stitch(cases[t1 << 0][i]);
	//General Case
	while(++y < dy -1){
		x =-1;
		t1 = values[(y*dx)+dx] >= threshold;
		t2 = values[y * dx] >= threshold;

		caseNum = t1 << 1 | t2 << 2;
		//if((caseNum != 0)&&(caseNum != 15)) {segCnt++; cout<<caseNum<<" SEGINC!\n\n";}

		for(int i = 0; i<= checkCaseLength(t1 << 1 | t2 << 2);i++) stitch(cases[t1 << 1 | t2 << 2][i]);
		while(++x<dx-1){


			t0 = t1;
			t1 = values[(y * dx)+ dx + x + 1] >= threshold;
			t3 = t2;
			t2 = values[y*dx+x+1]>= threshold;
			caseNum = t0|t1<<1|t2<<2|t3<<3;
			//printf("Case: %d\n",caseNum);
			//if((caseNum != 0)&&(caseNum != 15)) {segCnt++; cout<<caseNum<<" SEGINC!\n\n";}
			if(caseNum==5||caseNum ==10){
			noop();
			}

			for(int i = 0; i<= checkCaseLength(t0|t1<<1|t2<<2|t3<<3);i++) stitch(cases[t0|t1<<1|t2<<2|t3<<3][i]);
		}
		caseNum = t1 | t2 << 3 ;
		//if((caseNum != 0)&&(caseNum != 15)) {segCnt++; cout<<caseNum<<" SEGINC!\n\n";}
		for(int i = 0; i<= checkCaseLength(t1 | t2 << 3);i++) stitch(cases[t1 | t2 << 3][i]);

	}
	//Final Row
	x = -1;
	t2 = (values[y*dx] >= threshold);

	caseNum = t2 << 2 ;
	//if((caseNum != 0)&&(caseNum != 15)) {segCnt++; cout<<caseNum<<" SEGINC!\n\n";}

	for(int i = 0; i<= checkCaseLength(t2 << 2);i++) stitch(cases[t2 << 2][i]);
	while(++x < dx-1){
		t3 = t2;
		t2 = values[y*dx+x+1] >= threshold;

		caseNum = t2 << 2 | t3 << 3;
		//if((caseNum != 0)&&(caseNum != 15)) {segCnt++; cout<<caseNum<<" SEGINC!\n\n";}

		for(int i = 0; i<= checkCaseLength(t2 << 2 | t3 << 3);i++) stitch(cases[t2 << 2 | t3 << 3][i]);

	}

	caseNum = t2 << 3;
	//if((caseNum != 0)&&(caseNum != 15)) {segCnt++; cout<<caseNum<<" SEGINC!\n\n";}

	for(int i = 0; i<= checkCaseLength(t2 << 3);i++) stitch(cases[t2 << 3][i]);
	
}

int outOfBounds( double num){
double absolute = abs(num);
if((absolute <0.01)||(absolute > 100)||(std::isnan(absolute)))return 1;
else return 0;



}




    
int main(int argc, char *argv[]){

  if(argc == 1) {
    printf("Usage: %s\n", commandline);
    exit(-1);
  }

  struct arguments arguments;
  arguments.config_filename[0] = '\0';
  arguments.threshold = -1;
  argp_parse(&argp,argc,argv,0,0,&arguments);
  
  /*locate and verify the config file*/
  if (arguments.config_filename[0] == '\0') {
    /*locate and verify the config file*/
    char *d3_home = getenv("D3HOME");
    if (d3_home == NULL) {
      printf("please declare D3HOME or specify configfile on command line\n");
      exit(0);
    }
    else
      sprintf(arguments.config_filename, "%s/options.cfg", d3_home);
  }

  printf("config_filename: %s\n", arguments.config_filename);

  config_t config;
  config_setting_t *alg_params;
  
  config_init(&config);
  
  if (!config_read_file(&config, "options.cfg")) {
    printf("config file not found or contains errors.  Should be in $MRTHOME directory and called mrt_config.txt. exiting...\n");
    config_destroy(&config);
    return -1;
  }	
  
  
  int num_contour_levels = 0;
  alg_params = config_lookup(&config, "alg_params");
  int min_contour_points;
  int min_contour_points_present;
  int post_output;
  const config_setting_t *contour_levels;
  
  
  
  
  if (alg_params != NULL) {
    contour_levels = config_setting_lookup(alg_params, "contour_levels");
    if (contour_levels != NULL) {
      num_contour_levels = config_setting_length(contour_levels);
    }
    else {
      printf("No contour_levels defined.  Exiting.\n");
      exit(-1);
    }
    min_contour_points_present = config_setting_lookup_int(alg_params, "min_contour_points", &min_contour_points);
    config_lookup_int(&config,"post_output", &post_output);
    
    if (min_contour_points_present == CONFIG_FALSE) {
      printf("min_contour_points not defined. No size threshold will be used.");
      min_contour_points = 0;
    }
    else {
      //printf("Minimum contour points: %d\n", min_contour_points);
    }
  }
  else {
    printf("No alg_params in config file.  Exiting.\n");
    exit(-1);
  }
  float *contours; 
  if(arguments.threshold == -1){
    
    contours =(float*) malloc (sizeof (float)*num_contour_levels);
    
    int cl;
    for (cl = 0; cl < num_contour_levels; cl++) {
      contours[cl] = config_setting_get_float_elem(contour_levels, cl);
      printf("Contour level %d: %f\n", cl, contours[cl]);
    }
  }
  
  else{
    contours = (float*)malloc (sizeof (float));
    contours[0] = arguments.threshold;
    num_contour_levels =1;
  }

  cout << "contours " << contours[0] << endl;
  
  const char* post_url;
  const char* usrpass;
  const char* json_output_directory;
  int json_output;
  config_lookup_string(&config,"post_url", &post_url);
  config_lookup_string(&config,"usrpass", &usrpass);
  config_lookup_string(&config,"json_directory", &json_output_directory);
  config_lookup_int(&config,"json_output",&json_output);
  std::string output_directory = json_output_directory;
  

  const clock_t begin_time = clock();
  NcFile dataFile(arguments.i_filename, NcFile::ReadOnly);
  NcVar *latvar = dataFile.get_var(0);
  NcVar *lonvar = dataFile.get_var(1);
  NcVar *data = dataFile.get_var(2);

  char *token;
  char *rest = arguments.i_filename;
  token = strtok_r(rest, "_", &rest);
  token = strtok_r(rest, "_", &rest);
  char *ymd = token;
  token = strtok_r(rest, "_", &rest);
  char *strend = token;
  char *hms;
  hms = strtok_r(strend, ".", &strend);
 
  std::string name = "hmt_HAIL_CASA_";
  std::string timestamp = "";
  timestamp = timestamp.append(ymd);
  timestamp = timestamp.append("-");
  timestamp = timestamp.append(hms);
  std::string nameAndDate = name.append(timestamp);
  std::string hazardType = "HAIL_CASA";
  std::string yyyy = timestamp.substr(0,4);
  std::string mon = timestamp.substr(4,2);
  std::string dd = timestamp.substr(6,2);
  std::string hh = timestamp.substr(9,2);
  std::string mm = timestamp.substr(11,2);
  std::string ss = timestamp.substr(13,2);
  std::ostringstream alt_starttime;
  alt_starttime << yyyy << "-" << mon << "-" << dd << "T" << hh << ":" << mm << ":" << ss << "Z";
  
  //int x = (int)((*dataFile.get_dim("lat")).size());
  int x = 350;
  int y = (int)((*dataFile.get_dim("lon")).size());

  float latIn[x];
  float lonIn[y];
  float dataIn[y][x];
  dx = x;
  dy = y;

  latvar->get ( &latIn[0], x);
  lonvar->get ( &lonIn[0], y);
  data->get ( &dataIn[0][0], x, y );

  std::vector<double> netCDFValues;
  //This for-loop has to reverse the direction of the x values in order for them to be properly projected
  for(int f  = dy; f>0;f--){
    for(int g = 0; g<dx; g++){
      if(outOfBounds(dataIn[f][g]))  netCDFValues.push_back(0);
      //cout<<"f: "<<f<<" g: "<<g<<"val: "<<dataIn[f][g]<<endl;
      else netCDFValues.push_back((double)dataIn[f][g]);
    }
  }
  
  for(int i = 0; i<num_contour_levels;i++){
       
    //cout<<"Here: "<<contours[i]<<" "<<i<<endl;
    marchingSquares(contours[i],netCDFValues);
    std::string thresholdString= std::to_string(trunc(contours[i]));
    
    
    
    
    //for printing array 
    
    /*
      
      for (std::vector<double>::iterator it = netCDFValues.begin() ; it != netCDFValues.end(); ++it){
      //int count=0;
      //	if((*it>45) ) {
      
      cout<<"Iterator: ";
      cout<<it-netCDFValues.begin();
      cout<<" Value: ";
      
      cout<<*it;
      cout<<endl;
      //	}
      } 
      
    */
    pushHoles(latIn, x, lonIn, y);
    
    //cout<<"PUSH HOLES COMP\n";
    json j;
    
    json j2;
    
    //j2["test"] = polygonCollection[0];
    
    
    j["coordinates:"] = polygonCollection;
    
    j2["type"] = "FeatureCollection";
    int polyCountForPrint = 1;
    std::vector<std::vector<std::vector<std::pair<double,double>>>>::iterator polyIt;
    for(polyIt=polygonCollection.begin();polyIt!=polygonCollection.end();polyIt++){
      
      json tmp1;
      json tmp2;
      std::string temp = nameAndDate +"_"+std::to_string(polyCountForPrint);
      tmp2["type"] = "Polygon";
      tmp1["type"] = "Feature";
      tmp1["id"] = temp;
      tmp1["hazardType"] = hazardType;
      tmp1["properties"]["timestamp"] = alt_starttime.str();
      tmp1["properties"]["ReflectivityLevel"] = contours[i];
      tmp1["geometry"]["coordinates"] = *polyIt;
      tmp1["geometry"]["type"] = "Polygon";
      
      tmp1["properties"]["#"] = polyCountForPrint;
      
      
      //cout<<tmp1.dump(2)<<endl;
      j2["features"].push_back(tmp1);
      polyCountForPrint++;    }
    
    //cout<<j2.dump(3);
    
    //std:string s = j2["test"].dump(2);
    //cout<<polygonCollection.size()<<endl;
    
    
    
    //cout <<"Approximate time used: "<< float( clock () - begin_time ) /  CLOCKS_PER_SEC<<endl;
    
    
    
    
    
    //cout<<"j---"<<j.dump(3)<<endl;
    
    std::ofstream outfile;
    std::string outputFN = nameAndDate + ".geojson";
    
    
    if(json_output){
      outfile.open(output_directory + "/" + outputFN);
      outfile<<j2.dump(2);
    }
    char postbuf[j2.dump().length()+8];
    sprintf(postbuf,"json={\"name\":\"andrew\"}");
    
    
    //Curl 
    if(post_output){
      std::string post = "json="+j2.dump();//this builds the string containing the json object
      
      const char * c = post.c_str();
      //  cout<<post<<endl;
      CURL *curl;
      CURLcode res;
      		 	
      curl_global_init(CURL_GLOBAL_ALL);
      curl = curl_easy_init();
      if(curl) {
	curl_easy_setopt(curl, CURLOPT_URL, post_url);
	curl_easy_setopt(curl, CURLOPT_USERPWD, usrpass);
	
	curl_easy_setopt(curl, CURLOPT_POSTFIELDS, c);
	
	res = curl_easy_perform(curl);
	
	if(res != CURLE_OK)
	  fprintf(stderr, "curl_easy_perform() failed: %s\n",
		  curl_easy_strerror(res));
	
	curl_easy_cleanup(curl);
      }
      curl_global_cleanup();
      
    }
    
    //Cleanup
    polygonCollection.clear();
    
    polygons.clear();
    
    holes.clear();
    
    polygonTemp.clear();	
    
  }
  
  //Curl End
  
  return 0;
}//end main
