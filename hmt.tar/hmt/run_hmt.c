#include <stdlib.h>
#include <stdio.h>
#include <string.h>
#include <stdarg.h>
#include <math.h>
#include <argp.h>
#include "threshold_functions.h"
#include <sys/resource.h>

#define MAX_NAME 1024

char commandline[]= "hmt <-c configfile> [input_filename]" ;

static struct argp_option options[] = {
  {"configfile", 'c', "configuration_file",    0,   "Specify name of configuration file"},
  { 0 }
};

struct arguments{
  char config_filename[MAX_NAME];
  char *i_filename;
};

static error_t parse_opt(int key, char *arg, struct argp_state *state){
  struct arguments *arguments = state->input;
  switch(key){
  case 'c':
    if (arg[0] != '-')
      strncpy(arguments->config_filename,arg,MAX_NAME);
    else {
      printf("arguments should not begin with a - sign.  Exiting...\n");
      exit(0);
    }
    break;
  case ARGP_KEY_ARG:
    arguments->i_filename = arg;
    break;
  case ARGP_KEY_END:
    if(state->arg_num<1)
      argp_usage(state);
    break;
  default:
    return ARGP_ERR_UNKNOWN;
  }
  return 0;
}

static struct argp argp = {options,parse_opt,"$Id: hmt.c,v 1.0 2019-09-10 09:35:52 elyons Exp $"};

int main(int argc, char* argv[])
{
  if(argc == 1) {
    printf("Usage: %s\n", commandline);
    exit(-1);
  }

  struct arguments arguments;
  arguments.config_filename[0] = '\0';
  argp_parse(&argp,argc,argv,0,0,&arguments);

  /*locate and verify the config file*/
  if (arguments.config_filename[0] == '\0') {
    /*locate and verify the config file*/
    char *hmt_home = getenv("HMTHOME");
    if (hmt_home == NULL) {
      printf("please declare HMTHOME or specify configfile on command line\n");
      exit(0);
    }
    else
      sprintf(arguments.config_filename, "%s/hmt_config.txt", hmt_home);
  }

  printf("config_filename: %s\n", arguments.config_filename);
  
  
  const rlim_t kStackSize = 64L * 1024L * 1024L;   // min stack size = 64 Mb
  struct rlimit rl;
  int result;

  result = getrlimit(RLIMIT_STACK, &rl);
  if (result == 0) {
    if (rl.rlim_cur < kStackSize) {
      rl.rlim_cur = kStackSize;
      result = setrlimit(RLIMIT_STACK, &rl);
      if (result != 0) {
	fprintf(stderr, "setrlimit returned result = %d\n", result);
      }
    }
  }
  
  hmt(arguments.i_filename, arguments.config_filename);

  return 0;
}
